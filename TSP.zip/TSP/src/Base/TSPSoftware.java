package Base;

import Views.EntryPage;

public class TSPSoftware {

    public static void main(String[] args){
        EntryPage page = new EntryPage();
        page.setVisible(true);
    }
}
